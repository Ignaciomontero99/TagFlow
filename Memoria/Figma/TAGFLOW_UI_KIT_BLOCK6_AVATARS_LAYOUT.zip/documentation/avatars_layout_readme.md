# TagFlow UI Kit — Avatars & Layout Helpers

Includes:
- Avatars: S, M, L, XL + online indicator
- Light & Dark variants
- Layout helpers: safe area, divider, spacing, grid, containers

Formats:
- SVG (editable)
- PNG (preview)

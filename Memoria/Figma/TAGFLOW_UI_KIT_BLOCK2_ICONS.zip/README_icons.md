# TagFlow Icons
Hybrid iOS/Material, stroke 1.5.
Light & Dark variants.
SVG editable.

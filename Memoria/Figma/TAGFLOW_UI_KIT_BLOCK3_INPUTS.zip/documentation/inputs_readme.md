# Inputs HI-FI for TagFlow
Includes default, focus, error, filled, prefix, suffix, search, multiline.